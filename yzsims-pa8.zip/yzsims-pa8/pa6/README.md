
Description
Notes
List.h 
Contains well defined and relevant constructors, destructors, functions, and structures for expanded upon in List.cpp, and utilized in Shuffle.cpp and ListTest.cpp


List.cpp 
Implements a List ADT as a doubly-linked list. The ADT is used to…


ListTest.cpp  
Contains a test client that runs all of the List operations to confirm that they all run properly.


BigInteger.h
Contains well defined and relevant constructors, destructors, functions, and structures for expanded upon in BigInteger.cpp, and utilized in Arithmetic.cpp and BigInteger.cpp and BigIntegerTest,cpp.


BigInteger.cpp
Creates operations for Arithmeitc.cpp to perform on big integers.


BigIntegerTest.cpp
Contains a test client that runs all of the BigInteger operations to confirm that they all run properly.


Arithmetic.cpp
Utilizes the operations in BigInteger to perform arithmetic on big integers.


Makefile 
Allows the programmer to compile, test, and run code to ensure a functional compilation free of errors. It will notify the programmer of any errors with the code before ever placing the code in the class gradescript. The make file also creates and erases .o files 


README.md
Provides a list of all submitted files and a description of each one sometimes accompanied by a note. (This is a Readme file.)




